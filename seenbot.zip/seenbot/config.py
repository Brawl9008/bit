BOT_TOKEN = "5077190358:AAF2qxjWxKo1x91CgFFODtn9L-crt-TL-r0"
logchat = -728921870
#logchat это айди чата в которое будет идти все системные сообщения, пример - -100429349234

#слито в @smoke_software