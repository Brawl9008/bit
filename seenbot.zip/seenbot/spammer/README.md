# SPAMMER V1.0 💣
Установка в Termux:
```
git clone https://github.com/privatesoft0/spammer

cd spammer

python spam.py
```
